---
layout: list
permalink: /categories/
title: "Categories"
excerpt: "List of posts grouped by categories."
---

{%- include archive-list.html list_items=site.categories -%}